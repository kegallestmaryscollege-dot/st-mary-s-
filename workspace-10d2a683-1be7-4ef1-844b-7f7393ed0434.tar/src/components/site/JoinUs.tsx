"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Flame,
  Loader2,
  Mail,
  MessageSquareText,
  Send,
  UserRound,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import SectionHeading from "./SectionHeading";

const INTERESTS = [
  "Web & App Development",
  "Coding & Competitions",
  "Robotics & IoT",
  "AI & Data",
  "Design & Media",
  "ICT Support Squad",
  "Not sure yet — show me!",
];

export default function JoinUs() {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [grade, setGrade] = useState("");
  const [email, setEmail] = useState("");
  const [interest, setInterest] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setLoading(true);

    try {
      const res = await fetch("/api/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, grade, email, interest, message }),
      });
      const data = await res.json();

      if (res.ok && data.ok) {
        toast({
          title: "Application received!",
          description:
            "Welcome to the fire, " +
            name.split(" ")[0] +
            ". A senior member will reach out to you soon.",
        });
        setName("");
        setGrade("");
        setEmail("");
        setInterest("");
        setMessage("");
      } else {
        toast({
          title: "Could not submit",
          description: data.error ?? "Please check your details and try again.",
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "Network error",
        description: "The connection failed. Please try again in a moment.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fieldCls =
    "border-gold/25 bg-coal/70 text-parchment placeholder:text-ash/70 focus-visible:ring-ember/60 focus-visible:border-gold/50 h-11";

  return (
    <section
      id="join"
      className="relative z-10 scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-1/2 -z-10 mx-auto h-72 max-w-4xl -translate-y-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(255,122,18,0.10),transparent_70%)] blur-2xl"
      />
      <div className="mx-auto max-w-4xl">
        <SectionHeading
          eyebrow="Ignite Now"
          title="Join the Tech Section"
          subtitle="Tell us who you are and what excites you. No experience needed — curiosity is the only entry requirement."
        />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
        >
          <form
            onSubmit={onSubmit}
            className="glass-card rounded-3xl p-6 shadow-[0_24px_70px_rgba(0,0,0,0.5)] sm:p-9"
          >
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              {/* Name */}
              <div className="space-y-2">
                <label
                  htmlFor="join-name"
                  className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-gold-bright"
                >
                  <UserRound className="h-3.5 w-3.5" aria-hidden="true" />
                  Full Name
                </label>
                <Input
                  id="join-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Kasun Perera"
                  required
                  minLength={2}
                  maxLength={80}
                  className={fieldCls}
                />
              </div>

              {/* Grade */}
              <div className="space-y-2">
                <label
                  htmlFor="join-grade"
                  className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-gold-bright"
                >
                  <Flame className="h-3.5 w-3.5" aria-hidden="true" />
                  Grade / Class
                </label>
                <Input
                  id="join-grade"
                  value={grade}
                  onChange={(e) => setGrade(e.target.value)}
                  placeholder="e.g. Grade 10 - B"
                  required
                  maxLength={40}
                  className={fieldCls}
                />
              </div>

              {/* Email */}
              <div className="space-y-2 sm:col-span-2">
                <label
                  htmlFor="join-email"
                  className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-gold-bright"
                >
                  <Mail className="h-3.5 w-3.5" aria-hidden="true" />
                  Email
                </label>
                <Input
                  id="join-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className={fieldCls}
                />
              </div>

              {/* Interest */}
              <div className="space-y-2 sm:col-span-2">
                <label
                  htmlFor="join-interest"
                  className="block text-xs font-bold uppercase tracking-[0.2em] text-gold-bright"
                >
                  Domain you want to explore
                </label>
                <Select value={interest} onValueChange={setInterest} required>
                  <SelectTrigger id="join-interest" className={fieldCls}>
                    <SelectValue placeholder="Choose a domain" />
                  </SelectTrigger>
                  <SelectContent className="border-gold/25 bg-coal text-parchment">
                    {INTERESTS.map((it) => (
                      <SelectItem
                        key={it}
                        value={it}
                        className="focus:bg-gold/15 focus:text-gold-bright"
                      >
                        {it}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Message */}
              <div className="space-y-2 sm:col-span-2">
                <label
                  htmlFor="join-message"
                  className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-gold-bright"
                >
                  <MessageSquareText className="h-3.5 w-3.5" aria-hidden="true" />
                  Why do you want to join?
                </label>
                <Textarea
                  id="join-message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us about a project you dream of building, a game you want to make, or simply what makes you curious..."
                  required
                  minLength={10}
                  maxLength={600}
                  rows={4}
                  className="min-h-11 border-gold/25 bg-coal/70 text-parchment placeholder:text-ash/70 focus-visible:ring-ember/60 focus-visible:border-gold/50"
                />
              </div>
            </div>

            <div className="mt-7 flex flex-col items-center gap-4 sm:flex-row sm:justify-between">
              <p className="text-xs leading-relaxed text-ash">
                Applications are stored securely and reviewed by the committee.
                <br className="hidden sm:block" />
                St. Mary&apos;s College Kegalle · Tech Section
              </p>
              <Button
                type="submit"
                disabled={loading}
                className="h-12 min-w-44 rounded-full bg-gradient-to-r from-ember to-flame px-8 text-sm font-bold uppercase tracking-widest text-white shadow-[0_8px_28px_rgba(224,57,47,0.4)] transition-transform hover:scale-105 active:scale-95 disabled:opacity-70"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" aria-hidden="true" />
                    Send Application
                  </>
                )}
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
