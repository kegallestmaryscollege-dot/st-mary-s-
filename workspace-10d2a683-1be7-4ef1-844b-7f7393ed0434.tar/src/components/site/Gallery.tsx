"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";

const SHOTS = [
  {
    src: "/images/school-building.png",
    alt: "The main building of St. Mary's College Kegalle dressed in celebration flags",
    caption: "Our Home",
    sub: "The main building, dressed for celebration",
    wide: true,
  },
  {
    src: "/images/crest-fire.png",
    alt: "The college crest glowing amid fire and embers",
    caption: "The Crest",
    sub: "Lamp of knowledge, wreath of honour",
    wide: false,
  },
  {
    src: "/images/anniversary.png",
    alt: "150th anniversary emblem of St. Mary's College Kegalle, 1867 to 2017",
    caption: "150 Years",
    sub: "Sesquicentennial emblem, 1867–2017",
    wide: false,
  },
];

export default function Gallery() {
  return (
    <section
      id="gallery"
      className="relative z-10 scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Gallery"
          title="Frames of Pride"
          subtitle="A heritage worth every pixel."
        />

        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          {SHOTS.map((shot, i) => (
            <motion.figure
              key={shot.caption}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.65, delay: i * 0.14 }}
              className={`group relative overflow-hidden rounded-2xl border border-gold/20 shadow-[0_14px_44px_rgba(0,0,0,0.5)] ${
                shot.wide ? "md:col-span-2" : ""
              }`}
            >
              <div
                className={`relative w-full overflow-hidden ${
                  shot.wide
                    ? "aspect-[16/7]"
                    : "aspect-[16/10] md:aspect-auto md:h-full"
                }`}
              >
                <Image
                  src={shot.src}
                  alt={shot.alt}
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 rounded-2xl border border-transparent transition-colors duration-500 group-hover:border-gold/50"
                />
              </div>
              <figcaption className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
                <p className="font-display text-lg font-bold text-gold-bright sm:text-xl">
                  {shot.caption}
                </p>
                <p className="mt-0.5 text-xs text-parchment/80 sm:text-sm">
                  {shot.sub}
                </p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
