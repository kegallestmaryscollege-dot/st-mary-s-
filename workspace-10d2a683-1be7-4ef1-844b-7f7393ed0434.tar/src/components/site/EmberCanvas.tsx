"use client";

import { useEffect, useRef } from "react";

type Ember = {
  x: number;
  y: number;
  r: number;
  vy: number;
  vx: number;
  phase: number;
  freq: number;
  hue: number;
  sat: number;
  life: number;
  maxLife: number;
  twinkle: number;
};

/**
 * Full-screen fixed canvas of rising fire embers with a faint top-right
 * fire glow — mirrors the College crest banner. Mouse movement gently
 * pushes embers away. Honors prefers-reduced-motion.
 */
export default function EmberCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouse = useRef({ x: -9999, y: -9999 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let raf = 0;
    let width = 0;
    let height = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const embers: Ember[] = [];
    const isMobile = window.innerWidth < 768;
    const COUNT = reduced ? 0 : isMobile ? 42 : 95;

    const rand = (a: number, b: number) => a + Math.random() * (b - a);

    const spawn = (initial: boolean): Ember => ({
      x: rand(0, width),
      y: initial ? rand(0, height) : height + rand(4, 40),
      r: rand(0.6, 2.6),
      vy: rand(0.25, 1.05) * (isMobile ? 0.85 : 1),
      vx: rand(-0.18, 0.18),
      phase: rand(0, Math.PI * 2),
      freq: rand(0.004, 0.02),
      hue: rand(16, 46),
      sat: rand(80, 100),
      life: 0,
      maxLife: rand(360, 780),
      twinkle: rand(0.5, 1),
    });

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    for (let i = 0; i < COUNT; i++) embers.push(spawn(true));

    const onMove = (e: MouseEvent) => {
      mouse.current.x = e.clientX;
      mouse.current.y = e.clientY;
    };
    const onLeave = () => {
      mouse.current.x = -9999;
      mouse.current.y = -9999;
    };

    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseout", onLeave);

    let tick = 0;

    const draw = () => {
      tick += 1;
      ctx.clearRect(0, 0, width, height);

      // Faint fire glow, top-right — like the crest artwork
      const glowX = width * 0.82;
      const glowY = height * 0.12;
      const glowR = Math.max(width, height) * 0.32;
      const pulse = 0.5 + 0.5 * Math.sin(tick / 90);
      const g = ctx.createRadialGradient(glowX, glowY, 0, glowX, glowY, glowR);
      g.addColorStop(0, `rgba(224, 57, 47, ${0.1 + pulse * 0.05})`);
      g.addColorStop(0.4, `rgba(255, 122, 18, ${0.05 + pulse * 0.025})`);
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, width, height);

      for (let i = embers.length - 1; i >= 0; i--) {
        const e = embers[i];
        e.life += 1;
        e.phase += e.freq;

        // drift + mouse repulsion
        const dx = e.x - mouse.current.x;
        const dy = e.y - mouse.current.y;
        const dist2 = dx * dx + dy * dy;
        if (dist2 < 22500) {
          const d = Math.sqrt(dist2) || 1;
          const f = ((45 - d) / 45) * 0.9;
          e.x += (dx / d) * f;
          e.y += (dy / d) * f;
        }

        e.y -= e.vy;
        e.x += e.vx + Math.sin(e.phase) * 0.35;

        // fade in / fade out over life
        const t = e.life / e.maxLife;
        const alpha =
          t < 0.15 ? t / 0.15 : t > 0.75 ? Math.max(0, (1 - t) / 0.25) : 1;
        const flicker =
          0.55 + 0.45 * Math.sin(tick * 0.08 * e.twinkle + e.phase);

        const a = Math.max(0, alpha * flicker * 0.85);
        if (a <= 0.01) {
          embers.splice(i, 1);
          embers.push(spawn(false));
          continue;
        }

        const glow = ctx.createRadialGradient(e.x, e.y, 0, e.x, e.y, e.r * 4);
        glow.addColorStop(0, `hsla(${e.hue}, ${e.sat}%, 68%, ${a * 0.9})`);
        glow.addColorStop(0.35, `hsla(${e.hue}, ${e.sat}%, 52%, ${a * 0.5})`);
        glow.addColorStop(1, "hsla(20, 90%, 40%, 0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r * 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = `hsla(${e.hue + 6}, ${e.sat}%, 82%, ${a})`;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r * 0.8, 0, Math.PI * 2);
        ctx.fill();
      }

      raf = requestAnimationFrame(draw);
    };

    if (reduced) {
      // Static glow only
      const g = ctx.createRadialGradient(
        width * 0.82,
        height * 0.12,
        0,
        width * 0.82,
        height * 0.12,
        Math.max(width, height) * 0.3
      );
      g.addColorStop(0, "rgba(224, 57, 47, 0.12)");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, width, height);
    } else {
      raf = requestAnimationFrame(draw);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseout", onLeave);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0"
    />
  );
}
