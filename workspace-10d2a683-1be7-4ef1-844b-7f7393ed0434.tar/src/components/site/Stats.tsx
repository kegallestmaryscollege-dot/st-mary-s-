"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";

type Stat = {
  value: number;
  suffix: string;
  label: string;
  caption: string;
};

const STATS: Stat[] = [
  {
    value: 1867,
    suffix: "",
    label: "College Founded",
    caption: "A heritage of learning",
  },
  {
    value: 159,
    suffix: "",
    label: "Years of Legacy",
    caption: "And still burning bright",
  },
  {
    value: 6,
    suffix: "",
    label: "Tech Domains",
    caption: "One stage to master them all",
  },
  {
    value: 1,
    suffix: "",
    label: "Lamp of Knowledge",
    caption: "Passed from hand to hand",
  },
];

function CountUp({ target, start }: { target: number; start: boolean }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!start) return;
    const duration = 1600;
    const t0 = performance.now();
    let raf = 0;

    const step = (t: number) => {
      const p = Math.min((t - t0) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, start]);

  return <span>{display.toLocaleString("en-US")}</span>;
}

export default function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      ref={ref}
      aria-label="Key figures"
      className="relative z-10 px-4 py-16 sm:px-6 sm:py-20"
    >
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
        {STATS.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: i * 0.12 }}
            className="glass-card group rounded-2xl p-6 text-center transition-colors hover:border-gold/40"
          >
            <p className="font-display text-4xl font-black text-gold-gradient sm:text-5xl">
              <CountUp target={s.value} start={inView} />
            </p>
            <p className="mt-2 text-sm font-bold uppercase tracking-[0.18em] text-parchment/85">
              {s.label}
            </p>
            <p className="mt-1 text-xs text-ash">{s.caption}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
