"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Menu, Flame } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const LINKS = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#domains", label: "Domains" },
  { href: "#legacy", label: "Legacy" },
  { href: "#gallery", label: "Gallery" },
  { href: "#join", label: "Join Us" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
        scrolled
          ? "border-b border-gold/15 bg-ink/80 backdrop-blur-xl"
          : "bg-transparent"
      }`}
    >
      <nav
        className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:h-18 sm:px-6"
        aria-label="Main navigation"
      >
        <a href="#home" className="group flex items-center gap-3">
          <span className="relative flex h-10 w-10 items-center justify-center overflow-hidden rounded-full gold-hairline bg-coal shadow-[0_0_18px_rgba(255,122,24,0.25)]">
            <Image
              src="/images/crest-fire.png"
              alt="College crest"
              width={64}
              height={64}
              className="h-8 w-8 object-cover"
            />
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-[13px] font-bold tracking-wide text-gold-bright sm:text-sm">
              St. Mary&apos;s College
            </span>
            <span className="mt-1 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-[0.3em] text-ash">
              <Flame className="h-3 w-3 text-ember" aria-hidden="true" />
              Tech Section
            </span>
          </span>
        </a>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="rounded-full px-4 py-2 text-sm font-medium text-parchment/80 transition-colors hover:bg-gold/10 hover:text-gold-bright"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li>
            <a
              href="#join"
              className="ml-2 rounded-full bg-gradient-to-r from-ember to-flame px-4 py-2 text-sm font-semibold text-white shadow-[0_0_20px_rgba(255,122,24,0.35)] transition-transform hover:scale-105"
            >
              Ignite Now
            </a>
          </li>
        </ul>

        {/* Mobile menu */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger
            className="inline-flex h-11 w-11 items-center justify-center rounded-full gold-hairline bg-coal text-gold-bright md:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </SheetTrigger>
          <SheetContent
            side="right"
            className="w-72 border-gold/20 bg-coal/95 backdrop-blur-xl"
          >
            <SheetHeader>
              <SheetTitle className="font-display text-gold-bright">
                Tech Section
              </SheetTitle>
            </SheetHeader>
            <ul className="mt-4 flex flex-col gap-1 px-2">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="block rounded-lg px-4 py-3 text-base font-medium text-parchment/85 transition-colors hover:bg-gold/10 hover:text-gold-bright"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
            <p className="mt-6 px-4 text-xs uppercase tracking-[0.25em] text-ash">
              Not For Self, But For Country
            </p>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
