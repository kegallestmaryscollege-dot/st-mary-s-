"use client";

import { motion } from "framer-motion";
import {
  Award,
  BookOpenCheck,
  Camera,
  Crown,
  Megaphone,
  UserCog,
  type LucideIcon,
} from "lucide-react";
import SectionHeading from "./SectionHeading";

type Role = {
  icon: LucideIcon;
  role: string;
  duty: string;
};

/**
 * Role-based committee board. Real names are intentionally not fabricated —
 * the board is filled every year by students who join the section.
 */
const ROLES: Role[] = [
  {
    icon: Crown,
    role: "President",
    duty: "Leads the section, chairs meetings and answers for every project.",
  },
  {
    icon: Award,
    role: "Vice President",
    duty: "The second flame — steps in, backs up and keeps momentum.",
  },
  {
    icon: BookOpenCheck,
    role: "Secretary",
    duty: "Keeps minutes, plans sessions and guards the archive.",
  },
  {
    icon: UserCog,
    role: "Treasurer & Logistics",
    duty: "Manages funds, equipment and the lab you love.",
  },
  {
    icon: Camera,
    role: "Media Editor",
    duty: "Captures every event and makes it look legendary.",
  },
  {
    icon: Megaphone,
    role: "Outreach Coordinator",
    duty: "Connects the section with schools, clubs and sponsors.",
  },
];

export default function Committee() {
  return (
    <section
      id="crew"
      aria-label="Committee roles"
      className="relative z-10 px-4 py-20 sm:px-6 sm:py-24"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="The Crew"
          title="One Board, Six Torches"
          subtitle="The committee changes every year — the posts below are held by students like you. Nominations open at the start of each season."
        />

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {ROLES.map((r, i) => {
            const Icon = r.icon;
            return (
              <motion.div
                key={r.role}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.55, delay: (i % 3) * 0.1 }}
                className="group relative overflow-hidden rounded-2xl border border-gold/15 bg-coal/60 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-gold/40 hover:shadow-[0_10px_40px_rgba(255,122,18,0.12)]"
              >
                <div
                  aria-hidden="true"
                  className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent opacity-0 transition-opacity group-hover:opacity-100"
                />
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full border border-gold/30 bg-gradient-to-br from-coal to-[#1a0e05] text-gold-bright transition-colors group-hover:text-ember">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="font-display text-lg font-bold text-gold-bright">
                    {r.role}
                  </h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-parchment/75">
                  {r.duty}
                </p>
                <p className="mt-4 inline-flex items-center rounded-full border border-ember/40 bg-ember/10 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-ember">
                  Open to members
                </p>
              </motion.div>
            );
          })}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-10 text-center text-sm text-ash"
        >
          Positions are filled by students who apply below — your name could be
          on this board next season.
        </motion.p>
      </div>
    </section>
  );
}
