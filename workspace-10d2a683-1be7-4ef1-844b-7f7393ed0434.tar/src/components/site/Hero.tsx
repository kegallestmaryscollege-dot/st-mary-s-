"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { ChevronDown, Cpu, Sparkles } from "lucide-react";

const PHRASES = [
  "Not For Self, But For Country.",
  "Code. Create. Conquer.",
  "Igniting the Lamp of Knowledge.",
  "Building tomorrow's innovators.",
];

function useTyped(phrases: string[]) {
  const [text, setText] = useState("");
  const [pi, setPi] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = phrases[pi];
    let delay = deleting ? 28 : 62;
    if (!deleting && text === current) delay = 2100;
    else if (deleting && text === "") delay = 500;

    const t = setTimeout(() => {
      if (!deleting) {
        if (text === current) {
          setDeleting(true);
        } else {
          setText(current.slice(0, text.length + 1));
        }
      } else {
        if (text === "") {
          setDeleting(false);
          setPi((p) => (p + 1) % phrases.length);
        } else {
          setText(current.slice(0, text.length - 1));
        }
      }
    }, delay);
    return () => clearTimeout(t);
  }, [text, deleting, pi, phrases]);

  return text;
}

export default function Hero() {
  const typed = useTyped(PHRASES);

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden"
    >
      {/* warm backdrop washes */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 55% 45% at 78% 22%, rgba(224,57,47,0.16), transparent 65%), radial-gradient(ellipse 45% 40% at 15% 80%, rgba(217,164,65,0.08), transparent 60%)",
        }}
      />

      <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-10 px-4 pb-24 pt-28 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:gap-6 lg:pt-24">
        {/* Copy */}
        <div className="text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full gold-hairline bg-coal/70 px-4 py-2 text-xs font-semibold uppercase tracking-[0.25em] text-gold-bright"
          >
            <Sparkles className="h-3.5 w-3.5 text-ember" aria-hidden="true" />
            Est. 1867 · Kegalle, Sri Lanka
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="font-display text-4xl font-black leading-[1.08] sm:text-6xl lg:text-7xl"
          >
            <span className="text-gold-gradient">St. Mary&apos;s College</span>
            <span className="mt-1 block text-2xl font-semibold tracking-[0.18em] text-parchment/90 sm:text-3xl lg:text-4xl">
              KEGALLE
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-5 inline-flex items-center gap-3 font-display text-xl font-bold tracking-[0.32em] text-ember-gradient sm:text-2xl lg:text-3xl"
          >
            <Cpu className="h-6 w-6 text-ember" aria-hidden="true" />
            TECH SECTION
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="mt-6 min-h-[1.8em] font-mono text-sm text-parchment/75 sm:min-h-[1.6em] sm:text-lg"
            aria-live="polite"
          >
            <span className="text-ember">&gt;_</span> {typed}
            <span className="animate-caret ml-0.5 inline-block h-5 w-2 translate-y-0.5 bg-gold-bright sm:h-6" />
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.85 }}
            className="mt-9 flex flex-wrap items-center justify-center gap-4 lg:justify-start"
          >
            <a
              href="#join"
              className="animate-pulse-ring rounded-full bg-gradient-to-r from-ember to-flame px-8 py-3.5 text-sm font-bold uppercase tracking-widest text-white shadow-[0_8px_30px_rgba(224,57,47,0.4)] transition-transform hover:scale-105 active:scale-95"
            >
              Join the Section
            </a>
            <a
              href="#domains"
              className="rounded-full gold-hairline bg-coal/60 px-8 py-3.5 text-sm font-bold uppercase tracking-widest text-gold-bright backdrop-blur transition-colors hover:border-gold/50 hover:bg-gold/10"
            >
              Explore Domains
            </a>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.1 }}
            className="mt-10 text-xs font-medium uppercase tracking-[0.3em] text-ash"
          >
            “Light the lamp — then pass it on.”
          </motion.p>
        </div>

        {/* Crest */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.45 }}
          className="relative mx-auto w-64 sm:w-80 lg:w-full lg:max-w-md"
        >
          <div
            aria-hidden="true"
            className="absolute inset-0 -z-10 scale-125 rounded-full bg-[radial-gradient(circle,rgba(255,122,18,0.28),rgba(224,57,47,0.12)_45%,transparent_70%)] blur-xl"
          />
          <div className="animate-float">
            <div className="relative mx-auto aspect-square w-full overflow-hidden rounded-full border border-gold/30 shadow-[0_0_60px_rgba(255,122,18,0.28),0_0_120px_rgba(224,57,47,0.15)]">
              <Image
                src="/images/crest-fire.png"
                alt="The crest of St. Mary's College Kegalle, lit by fire"
                fill
                priority
                sizes="(max-width: 640px) 256px, (max-width: 1024px) 320px, 448px"
                className="object-cover"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_75%_20%,rgba(255,150,60,0.22),transparent_50%)]"
              />
            </div>
          </div>
          <div className="animate-flicker mx-auto mt-6 flex w-fit items-center gap-2 rounded-full border border-gold/25 bg-coal/80 px-5 py-2 backdrop-blur">
            <span className="h-2 w-2 rounded-full bg-ember shadow-[0_0_10px_rgba(255,122,18,0.9)]" />
            <span className="text-[11px] font-semibold uppercase tracking-[0.28em] text-gold-bright">
              The Flame Lives On
            </span>
          </div>
        </motion.div>
      </div>

      {/* Scroll cue */}
      <a
        href="#legacy"
        aria-label="Scroll down to legacy section"
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-ash transition-colors hover:text-gold-bright sm:flex"
      >
        <span className="text-[10px] font-semibold uppercase tracking-[0.3em]">
          Scroll
        </span>
        <span className="flex h-9 w-5 items-start justify-center rounded-full border border-gold/30 p-1">
          <span className="animate-scroll-dot h-1.5 w-1.5 rounded-full bg-gold-bright" />
        </span>
        <ChevronDown className="h-4 w-4" aria-hidden="true" />
      </a>
    </section>
  );
}
