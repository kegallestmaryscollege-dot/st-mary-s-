"use client";

import Image from "next/image";
import { Flame } from "lucide-react";

const NAV = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#domains", label: "Domains" },
  { href: "#legacy", label: "Legacy" },
  { href: "#gallery", label: "Gallery" },
  { href: "#join", label: "Join Us" },
];

export default function Footer() {
  return (
    <footer className="relative z-10 mt-auto border-t border-gold/15 bg-coal/80 backdrop-blur">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-3">
            <span className="relative flex h-12 w-12 items-center justify-center overflow-hidden rounded-full border border-gold/30 bg-black shadow-[0_0_18px_rgba(255,122,24,0.3)]">
              <Image
                src="/images/crest-fire.png"
                alt="College crest"
                width={96}
                height={96}
                className="h-9 w-9 object-cover"
              />
            </span>
            <div className="leading-tight">
              <p className="font-display text-sm font-bold text-gold-bright">
                St. Mary&apos;s College Kegalle
              </p>
              <p className="mt-0.5 flex items-center gap-1 text-[11px] font-semibold uppercase tracking-[0.25em] text-ash">
                <Flame className="h-3 w-3 text-ember" aria-hidden="true" />
                Tech Section
              </p>
            </div>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-parchment/70">
            The digital workshop of a 159-year-old college — building the
            future while honouring the flame.
          </p>
        </div>

        {/* Quick links */}
        <nav aria-label="Footer navigation">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.3em] text-gold-bright">
            Navigate
          </p>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-2">
            {NAV.map((n) => (
              <li key={n.href}>
                <a
                  href={n.href}
                  className="text-sm text-parchment/70 transition-colors hover:text-gold-bright"
                >
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {/* Motto */}
        <div className="md:text-right">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.3em] text-gold-bright">
            Our Motto
          </p>
          <p className="font-display text-xl font-bold leading-snug text-ember-gradient sm:text-2xl">
            “Not For Self,
            <br />
            But For Country.”
          </p>
          <p className="mt-3 text-xs text-ash">
            Est. 1867 · Kegalle, Sri Lanka
          </p>
        </div>
      </div>

      <div className="border-t border-gold/10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-4 text-xs text-ash sm:flex-row sm:px-6">
          <p>
            © {new Date().getFullYear()} Tech Section — St. Mary&apos;s College
            Kegalle.
          </p>
          <p className="font-mono">
            built by students, for students <span className="text-ember">▮</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
