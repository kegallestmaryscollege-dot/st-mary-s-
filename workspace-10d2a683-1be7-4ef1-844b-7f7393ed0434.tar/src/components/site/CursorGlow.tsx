"use client";

import { useEffect, useRef } from "react";

/**
 * A warm lantern-glow that trails the cursor. Pure decoration —
 * pointer-events disabled, hidden for touch devices and coarse pointers
 * via CSS, and disabled when the user prefers reduced motion.
 */
export default function CursorGlow() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) return;

    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    const pos = { ...target };
    let raf = 0;

    const onMove = (e: MouseEvent) => {
      target.x = e.clientX;
      target.y = e.clientY;
    };

    const loop = () => {
      pos.x += (target.x - pos.x) * 0.12;
      pos.y += (target.y - pos.y) * 0.12;
      if (ref.current) {
        ref.current.style.transform = `translate3d(${pos.x - 190}px, ${
          pos.y - 190
        }px, 0)`;
      }
      raf = requestAnimationFrame(loop);
    };

    window.addEventListener("mousemove", onMove, { passive: true });
    raf = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      ref={ref}
      className="pointer-events-none fixed left-0 top-0 z-[3] hidden h-[380px] w-[380px] rounded-full opacity-60 [@media(pointer:fine)]:block"
      style={{
        background:
          "radial-gradient(circle, rgba(255,140,40,0.10) 0%, rgba(217,164,65,0.06) 35%, transparent 70%)",
        mixBlendMode: "screen",
      }}
    />
  );
}
