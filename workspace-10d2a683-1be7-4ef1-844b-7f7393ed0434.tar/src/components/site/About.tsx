"use client";

import { motion } from "framer-motion";
import { BookOpen, Flame } from "lucide-react";
import SectionHeading from "./SectionHeading";

const CODE_LINES = [
  {
    prompt: "$",
    text: 'ignite --motto "Not For Self, But For Country"',
    cls: "text-parchment/85",
  },
  {
    prompt: ">",
    text: "Loading heritage... founded 1867 ✓",
    cls: "text-ash",
  },
  {
    prompt: ">",
    text: "Lamp of Knowledge: ON",
    cls: "text-ember",
  },
  { prompt: "$", text: "tech-section deploy --to 2026", cls: "text-parchment/85" },
  {
    prompt: ">",
    text: "students.motivated() => true",
    cls: "text-gold-bright",
  },
  {
    prompt: ">",
    text: "future.compiling() => 'bright'",
    cls: "text-gold-bright",
  },
  { prompt: "$", text: "▍", cls: "text-ember animate-caret" },
];

export default function About() {
  return (
    <section id="about" className="relative z-10 scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Who We Are"
          title="The Tech Section"
          subtitle="Where a 159-year-old flame meets the circuits of tomorrow."
        />

        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-2 lg:gap-14">
          {/* Narrative */}
          <motion.div
            initial={{ opacity: 0, x: -32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="glass-card rounded-2xl p-6 sm:p-8">
              <div className="mb-4 flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-ember to-flame shadow-[0_0_18px_rgba(255,122,24,0.4)]">
                  <Flame className="h-5 w-5 text-white" aria-hidden="true" />
                </span>
                <h3 className="font-display text-xl font-bold text-gold-bright sm:text-2xl">
                  Born from the Lamp
                </h3>
              </div>
              <div className="space-y-4 text-sm leading-relaxed text-parchment/80 sm:text-base">
                <p>
                  In the heart of Kegalle stands a college that has carried the
                  lamp of knowledge since 1867. The{" "}
                  <strong className="text-gold-bright">Tech Section of
                  St. Mary&apos;s College</strong> is the newest bearer of that
                  flame — a crew of students who build, break, debug and dream
                  in code, circuits and pixels.
                </p>
                <p>
                  We are the digital workshop of the college: we craft its
                  websites, run its coding competitions, tinker with robotics
                  and Arduino, explore artificial intelligence, and tell
                  stories through design and media. Every project we ship
                  carries one promise — our school motto,{" "}
                  <em className="text-ember-gradient font-semibold not-italic">
                    “Not For Self, But For Country.”
                  </em>
                </p>
                <p>
                  Whether you have written a thousand programs or have never
                  opened a terminal, there is a seat by the fire for you. All
                  you need is curiosity — we&apos;ll teach you the rest.
                </p>
              </div>

              <div className="mt-6 flex flex-wrap gap-2">
                {["Curiosity First", "Hands On", "Learn by Building", "Serve the Nation"].map(
                  (chip) => (
                    <span
                      key={chip}
                      className="rounded-full border border-gold/25 bg-gold/5 px-3.5 py-1.5 text-xs font-semibold tracking-wide text-gold-bright"
                    >
                      {chip}
                    </span>
                  )
                )}
              </div>
            </div>
          </motion.div>

          {/* Terminal */}
          <motion.div
            initial={{ opacity: 0, x: 32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.15 }}
            className="relative"
          >
            <div
              aria-hidden="true"
              className="absolute -inset-3 rounded-3xl bg-[radial-gradient(ellipse_at_center,rgba(255,122,18,0.12),transparent_70%)] blur-lg"
            />
            <div className="relative overflow-hidden rounded-2xl border border-gold/25 bg-[#0c0805] shadow-[0_20px_60px_rgba(0,0,0,0.6)]">
              <div className="flex items-center gap-2 border-b border-gold/15 bg-black/40 px-4 py-3">
                <span className="h-3 w-3 rounded-full bg-flame/80" />
                <span className="h-3 w-3 rounded-full bg-gold/70" />
                <span className="h-3 w-3 rounded-full bg-[#3f8f43]" />
                <span className="ml-3 font-mono text-xs text-ash">
                  tech-section@smc-kegalle:~
                </span>
                <BookOpen
                  className="ml-auto h-4 w-4 text-gold/50"
                  aria-hidden="true"
                />
              </div>
              <div className="space-y-2.5 p-5 font-mono text-xs sm:text-sm">
                {CODE_LINES.map((line, i) => (
                  <motion.p
                    key={i}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.4 + i * 0.22, duration: 0.3 }}
                    className={line.cls}
                  >
                    <span className="mr-2 font-bold text-ember">
                      {line.prompt}
                    </span>
                    {line.text}
                  </motion.p>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
