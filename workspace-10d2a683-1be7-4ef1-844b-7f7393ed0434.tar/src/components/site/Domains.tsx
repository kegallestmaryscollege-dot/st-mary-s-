"use client";

import { useRef } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from "framer-motion";
import {
  Bot,
  BrainCircuit,
  Code2,
  Palette,
  Trophy,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import SectionHeading from "./SectionHeading";

type Domain = {
  icon: LucideIcon;
  title: string;
  tagline: string;
  points: string[];
};

const DOMAINS: Domain[] = [
  {
    icon: Code2,
    title: "Web & App Development",
    tagline: "Ship real products for the college",
    points: [
      "Build the college website & event apps",
      "HTML, CSS, JavaScript, React & Next.js",
      "From first <div> to full-stack projects",
    ],
  },
  {
    icon: Trophy,
    title: "Coding & Competitions",
    tagline: "Represent SMC on every stage",
    points: [
      "Inter-school hackathons & olympiads",
      "Python, Scratch & algorithm practice",
      "In-house Tech Day battles",
    ],
  },
  {
    icon: Bot,
    title: "Robotics & IoT",
    tagline: "Make the physical world listen",
    points: [
      "Arduino, sensors & smart gadgets",
      "Line followers, bots & automation",
      "School science-day exhibits",
    ],
  },
  {
    icon: BrainCircuit,
    title: "AI & Data",
    tagline: "Teach machines new tricks",
    points: [
      "Intro to machine learning concepts",
      "Chatbots & creative AI experiments",
      "Responsible, ethical AI use",
    ],
  },
  {
    icon: Palette,
    title: "Design & Media",
    tagline: "Tell stories that glow",
    points: [
      "Posters, banners & social media",
      "Photo & video coverage of events",
      "Canva, Figma & editing basics",
    ],
  },
  {
    icon: Wrench,
    title: "ICT Support Squad",
    tagline: "Keep the college running",
    points: [
      "Maintain school lab & AV systems",
      "Help teachers with tech in class",
      "Digital safety awareness drives",
    ],
  },
];

function TiltCard({ domain, index }: { domain: Domain; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [7, -7]), {
    stiffness: 180,
    damping: 18,
  });
  const ry = useSpring(useTransform(mx, [0, 1], [-7, 7]), {
    stiffness: 180,
    damping: 18,
  });

  const Icon = domain.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay: (index % 3) * 0.12 }}
      style={{ perspective: 900 }}
    >
      <motion.div
        ref={ref}
        onMouseMove={(e) => {
          const r = ref.current?.getBoundingClientRect();
          if (!r) return;
          mx.set((e.clientX - r.left) / r.width);
          my.set((e.clientY - r.top) / r.height);
        }}
        onMouseLeave={() => {
          mx.set(0.5);
          my.set(0.5);
        }}
        style={{ rotateX: rx, rotateY: ry, transformStyle: "preserve-3d" }}
        className="group glass-card relative h-full overflow-hidden rounded-2xl p-6 transition-colors duration-300 hover:border-gold/45 sm:p-7"
      >
        <div
          aria-hidden="true"
          className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[radial-gradient(circle,rgba(255,122,18,0.18),transparent_70%)] opacity-0 blur-md transition-opacity duration-300 group-hover:opacity-100"
        />
        <div
          className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-gold/25 bg-gradient-to-br from-coal to-[#1c0f06] text-gold-bright transition-all duration-300 group-hover:from-ember group-hover:to-flame group-hover:text-white group-hover:shadow-[0_0_22px_rgba(255,122,24,0.45)]"
          style={{ transform: "translateZ(30px)" }}
        >
          <Icon className="h-6 w-6" aria-hidden="true" />
        </div>
        <h3
          className="font-display text-lg font-bold text-parchment sm:text-xl"
          style={{ transform: "translateZ(22px)" }}
        >
          {domain.title}
        </h3>
        <p className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-ember">
          {domain.tagline}
        </p>
        <ul className="mt-4 space-y-2">
          {domain.points.map((p) => (
            <li
              key={p}
              className="flex items-start gap-2 text-sm leading-snug text-parchment/75"
            >
              <span
                className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold/70"
                aria-hidden="true"
              />
              {p}
            </li>
          ))}
        </ul>
      </motion.div>
    </motion.div>
  );
}

export default function Domains() {
  return (
    <section
      id="domains"
      className="relative z-10 scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="What We Do"
          title="Six Domains of Fire"
          subtitle="Pick a path — or walk them all. Every domain is student-led, project-based and open to newcomers."
        />
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {DOMAINS.map((d, i) => (
            <TiltCard key={d.title} domain={d} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
