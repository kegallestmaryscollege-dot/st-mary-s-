"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Flag, Medal, FlameKindling } from "lucide-react";
import SectionHeading from "./SectionHeading";

const MILESTONES = [
  {
    year: "1867",
    icon: Flag,
    title: "The Lamp Is Lit",
    body: "St. Mary's College is founded in Kegalle, Sri Lanka — beginning a tradition of knowledge, discipline and service that will burn for generations.",
  },
  {
    year: "2017",
    icon: Medal,
    title: "150 Years of Glory",
    body: "The college celebrates its sesquicentennial. One hundred and fifty years of alumni, achievement and the motto that binds them all: Not For Self, But For Country.",
  },
  {
    year: "TODAY",
    icon: FlameKindling,
    title: "The Flame Goes Digital",
    body: "The Tech Section carries the same lamp into the digital age — building, coding and innovating so that the next 150 years are shaped by the students of today.",
  },
];

export default function Timeline() {
  return (
    <section
      id="legacy"
      className="relative z-10 scroll-mt-20 px-4 py-20 sm:px-6 sm:py-24"
    >
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Our Legacy"
          title="From 1867 to the Cloud"
          subtitle="159 years of heritage stand behind every line of code we write."
        />

        <div className="relative mx-auto max-w-3xl">
          {/* the burning line */}
          <div
            aria-hidden="true"
            className="absolute left-6 top-0 h-full w-px bg-gradient-to-b from-ember via-gold/60 to-flame/40 sm:left-1/2"
          />

          <div className="space-y-12">
            {MILESTONES.map((m, i) => {
              const left = i % 2 === 0;
              const Icon = m.icon;
              return (
                <motion.div
                  key={m.year}
                  initial={{ opacity: 0, y: 32 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.7 }}
                  className={`relative flex ${
                    left ? "sm:justify-start" : "sm:justify-end"
                  }`}
                >
                  {/* node */}
                  <span
                    aria-hidden="true"
                    className="absolute left-6 top-6 z-10 flex h-5 w-5 -translate-x-1/2 items-center justify-center rounded-full border-2 border-gold bg-ink shadow-[0_0_14px_rgba(255,122,18,0.8)] sm:left-1/2"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-ember" />
                  </span>

                  <div
                    className={`glass-card ml-14 w-full rounded-2xl p-6 sm:ml-0 sm:w-[calc(50%-2.5rem)] ${
                      left ? "" : "sm:ml-auto"
                    }`}
                  >
                    <div className="mb-3 flex items-center gap-3">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-ember to-flame text-white">
                        <Icon className="h-5 w-5" aria-hidden="true" />
                      </span>
                      <span className="font-display text-2xl font-black text-gold-gradient sm:text-3xl">
                        {m.year}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-bold text-parchment">
                      {m.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-parchment/75">
                      {m.body}
                    </p>
                    {m.year === "2017" && (
                      <div className="mt-4 overflow-hidden rounded-xl border border-gold/20">
                        <Image
                          src="/images/anniversary.png"
                          alt="St. Mary's College Kegalle 150th anniversary crest, 1867–2017"
                          width={1254}
                          height={1254}
                          className="h-44 w-full object-cover object-center"
                        />
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
