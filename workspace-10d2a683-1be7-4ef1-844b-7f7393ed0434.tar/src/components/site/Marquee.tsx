"use client";

import { motion } from "framer-motion";
import { Diamond } from "lucide-react";

const ITEMS = [
  "WEB DEVELOPMENT",
  "ROBOTICS",
  "ARTIFICIAL INTELLIGENCE",
  "CODING",
  "DESIGN & MEDIA",
  "IOT",
  "HACKATHONS",
  "PYTHON",
  "ARDUINO",
  "UI / UX",
  "CLOUD",
  "OPEN SOURCE",
];

export default function Marquee() {
  const row = (
    <ul className="flex shrink-0 items-center" aria-hidden="false">
      {ITEMS.map((item) => (
        <li key={item} className="flex items-center">
          <span className="px-6 font-display text-sm font-semibold tracking-[0.3em] text-parchment/70 sm:text-base">
            {item}
          </span>
          <Diamond
            className="h-3 w-3 fill-ember text-ember"
            aria-hidden="true"
          />
        </li>
      ))}
    </ul>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1 }}
      className="relative z-10 border-y border-gold/15 bg-coal/70 py-4 backdrop-blur"
    >
      <div className="flex overflow-hidden">
        <div className="animate-marquee flex min-w-max">
          {row}
          {row}
        </div>
      </div>
    </motion.div>
  );
}
