"use client";

import { motion } from "framer-motion";

export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
}) {
  const centered = align === "center";
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className={`mb-12 ${centered ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}`}
    >
      <p
        className={`mb-3 flex items-center gap-3 text-xs font-bold uppercase tracking-[0.35em] text-ember ${
          centered ? "justify-center" : ""
        }`}
      >
        <span className="inline-block h-px w-8 bg-gradient-to-r from-transparent to-ember" />
        {eyebrow}
        <span className="inline-block h-px w-8 bg-gradient-to-l from-transparent to-ember" />
      </p>
      <h2 className="font-display text-3xl font-bold leading-tight text-gold-gradient sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-4 text-base leading-relaxed text-ash sm:text-lg">
          {subtitle}
        </p>
      )}
    </motion.div>
  );
}
