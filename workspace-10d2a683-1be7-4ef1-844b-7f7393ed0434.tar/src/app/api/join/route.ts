import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const joinSchema = z.object({
  name: z.string().trim().min(2, "Name is too short").max(80),
  grade: z.string().trim().min(1, "Grade / class is required").max(40),
  email: z.string().trim().email("Enter a valid email").max(120),
  interest: z.string().trim().min(1, "Pick a domain").max(60),
  message: z
    .string()
    .trim()
    .min(10, "Tell us a bit more (min 10 characters)")
    .max(600),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = joinSchema.safeParse(body);

    if (!parsed.success) {
      const first = parsed.error.issues[0];
      return NextResponse.json(
        { ok: false, error: first?.message ?? "Invalid application" },
        { status: 400 }
      );
    }

    const saved = await db.joinApplication.create({
      data: parsed.data,
    });

    return NextResponse.json({ ok: true, id: saved.id }, { status: 201 });
  } catch (err) {
    console.error("Join application failed:", err);
    return NextResponse.json(
      { ok: false, error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const count = await db.joinApplication.count();
    return NextResponse.json({ ok: true, count });
  } catch {
    return NextResponse.json({ ok: false, count: 0 }, { status: 500 });
  }
}
