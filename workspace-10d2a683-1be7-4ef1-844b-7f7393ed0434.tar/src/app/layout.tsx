import type { Metadata } from "next";
import { Cinzel, Manrope, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cinzel = Cinzel({
  variable: "--font-cinzel",
  subsets: ["latin"],
  weight: ["400", "600", "700", "900"],
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
});

const jetbrains = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Tech Section | St. Mary's College Kegalle",
  description:
    "Official website of the Tech Section of St. Mary's College Kegalle, Sri Lanka. Est. 1867 — Not For Self, But For Country. Web development, robotics, AI, coding and design — igniting the lamp of knowledge for the digital age.",
  keywords: [
    "St. Mary's College Kegalle",
    "Tech Section",
    "ICT Society",
    "Sri Lanka school technology",
    "coding club",
    "robotics",
  ],
  authors: [{ name: "Tech Section - St. Mary's College Kegalle" }],
  icons: {
    icon: "/images/crest-fire.png",
  },
  openGraph: {
    title: "Tech Section | St. Mary's College Kegalle",
    description:
      "Igniting the Lamp of Knowledge for the digital age. Est. 1867 — Not For Self, But For Country.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${cinzel.variable} ${manrope.variable} ${jetbrains.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
