import EmberCanvas from "@/components/site/EmberCanvas";
import CursorGlow from "@/components/site/CursorGlow";
import ScrollProgress from "@/components/site/ScrollProgress";
import Navbar from "@/components/site/Navbar";
import Hero from "@/components/site/Hero";
import Marquee from "@/components/site/Marquee";
import Stats from "@/components/site/Stats";
import About from "@/components/site/About";
import Domains from "@/components/site/Domains";
import Timeline from "@/components/site/Timeline";
import Committee from "@/components/site/Committee";
import Gallery from "@/components/site/Gallery";
import JoinUs from "@/components/site/JoinUs";
import Footer from "@/components/site/Footer";

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col overflow-x-clip bg-ink text-parchment">
      {/* Atmosphere layers */}
      <EmberCanvas />
      <CursorGlow />
      <div className="vignette" aria-hidden="true" />
      <div className="grain-overlay" aria-hidden="true" />
      <ScrollProgress />

      <Navbar />

      <main className="flex-1">
        <Hero />
        <Marquee />
        <Stats />
        <About />
        <Domains />
        <Timeline />
        <Committee />
        <Gallery />
        <JoinUs />
      </main>

      <Footer />
    </div>
  );
}
